# mod installer lets you install minecraft mods directly into the mods folder instead of having to put them in manually

good for people who are tired of navigating to the thingy every time you want to do a thing


it runs on python so you have to install that from <a href="https://www.python.org/downloads/">here</a> or from the <a href="https://apps.microsoft.com/search/publisher?name=Python+Software+Foundation&hl=en-us&gl=US">microsoft store</a>

# installation

this only works on windows because i dont feel like learning linux or mac<br>just download the code as a .zip and extract

on first time installs just  execute "first_time_install" (make sure the folder is in the directory you want because thats how the command thing works and if you move the folder it wont work any more)

you can change your mods folder directory in the "mods_folder_directory" text file (only the first line please)